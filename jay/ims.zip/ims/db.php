
<?php 

define('HOSTNAME', 'localhost');
define('USERNAME', 'root');
define('PASSWORD', '');
define('DATABASE', 'ims_data');

$con = mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DATABASE);


?>